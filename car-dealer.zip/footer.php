<!DOCTYPE html>
<html lang="en">
<head>
    <title>Premium Deluxe Motorsport</title>
</head>
<body>
<div class="footer">
<p><strong>PDM sportcar</strong><br>
      FMFI UK<br>
			Mlynská dolina<br>
			842 48 Bratislava<br>
			tel: +421 2 123 456 <br>
			e-mail: info@PDMsportcar.sk</p>
</div>
        </body>
</html>