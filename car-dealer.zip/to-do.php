<?php
/*
What's left:
___
TESTS
- show available test drive dates after clicking on the car

- "add test drive" button on each car for admin

- input userid into the test-drives after choosing date


$sql= "insert into TESTS (user id) VALUES ? WHERE date= ?

$date=$_GET[date]
$id=$_SESSION[usersID]

execute

 
----
RATING
- add rating button

- rating form

- insert into rating (uid , idc , points) values ? ? ?

----
RANDOM

- on index page "Hello , User"